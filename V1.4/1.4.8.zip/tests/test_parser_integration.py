# tests/test_parser_integration.py
import os, json, shutil
from core.procesar_recetas import procesar_archivo

def test_procesar_archivo_txt_end_to_end(tmp_path):
    contenido = (
        "Ingredientes para 2 porciones:\n"
        "1 ½ taza de leche\n"
        "2-3 cdas azúcar\n"
        "Preparación:\nMezclar todo."
    )
    recipe_txt = tmp_path / "receta_prueba.txt"
    recipe_txt.write_text(contenido, encoding="utf-8")

    # Ejecutar función de alto nivel
    assert procesar_archivo(str(recipe_txt))

    # Ruta donde procesar_archivo guarda el JSON
    json_name = f"{recipe_txt.stem}.json"
    out_json = os.path.join("recetas/procesadas/Recetas JSON", json_name)

    with open(out_json, encoding="utf-8") as f:
        data = json.load(f)

    # Comprobaciones clave
    assert data["ingredientes"][0]["cantidad"] == 1.5
    assert any(i["nombre"].lower().startswith("azúcar") for i in data["ingredientes"])

    # Limpieza de artefactos creados por la prueba
    shutil.rmtree("recetas/procesadas", ignore_errors=True)
