import pytest
from core.normalizador_recetas import (
    parsear_linea_ingrediente,
    parsear_ingredientes,
)

# ── Casos unitarios: fracciones, rangos, inglés/español ─────────────
@pytest.mark.parametrize(
    "linea,cantidad,unidad,nombre",
    [
        ("1 ½ taza de leche", 1.5, "taza",  "leche"),
        ("2-3 cdas azúcar",   2.0, "cda",   "azúcar"),   # toma mínimo del rango
        ("½ cup milk",        0.5, "cup",   "milk"),
        ("1⁄4 tsp sal",       0.25,"tsp",   "sal"),
    ],
)
def test_parsear_linea_fracciones(linea, cantidad, unidad, nombre):
    ing = parsear_linea_ingrediente(linea)
    assert pytest.approx(cantidad) == ing["cantidad"]
    assert ing["unidad"].lower() == unidad
    assert nombre.lower() in ing["nombre"].lower()


def test_parsear_ingredientes_encabezado_flexible():
    texto = (
        "Ingredientes para 4 porciones:\n"
        "1 ½ taza de leche\n"
        "2 huevos\n"
        "Preparación:\nMezclar todo"
    )
    ings = parsear_ingredientes(texto)
    nombres = {i["nombre"].lower() for i in ings}
    assert {"leche", "huevos"} <= nombres
