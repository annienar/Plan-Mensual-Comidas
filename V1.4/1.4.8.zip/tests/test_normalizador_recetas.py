import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from core.logger import configurar_logger, log_info
from core.normalizador_recetas import normalizar_receta_desde_texto

logger = configurar_logger("test_normalizador_recetas")

def probar_receta_desde_texto():
    texto = """
Pan bao casero, cómo hacerlo en casa paso a paso fácil
https://www.bonviveur.es/recetas/pan-bao-casero

Para hacer la masa:
- 300 g harina
- 180 ml leche
- 10 g levadura
- 1 cda azúcar

Preparación:
1. Mezclar los ingredientes secos.
2. Agregar la leche y amasar.
3. Dejar reposar.
"""

    receta = normalizar_receta_desde_texto(texto)
    log_info(f"🍴 Resultado: {receta['nombre']}")
    if 'origen' in receta:
        log_info(f"🔗 Origen detectado: {receta['origen']}")
    else:
        log_info("🔍 Sin URL de origen detectada.")

    if receta["ingredientes"]:
        log_info(f"✅ Ingredientes detectados: {len(receta['ingredientes'])}")
    else:
        log_info("❌ No se detectaron ingredientes.")

if __name__ == "__main__":
    probar_receta_desde_texto()
