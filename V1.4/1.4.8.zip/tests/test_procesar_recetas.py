from core.logger import configurar_logger, log_info, log_warning, log_error
from core.procesar_recetas import procesar_todo_en_sin_procesar

configurar_logger("test_procesar_recetas")

if __name__ == "__main__":
    procesar_todo_en_sin_procesar()
