from core.logger import configurar_logger, log_info, log_warning, log_error
logger = configurar_logger, log_info, log_warning, log_error("gestor")

class GestorPlanComidas:
    def __init__(self):
        pass
