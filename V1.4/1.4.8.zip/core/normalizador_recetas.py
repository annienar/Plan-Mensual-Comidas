# core/normalizador_recetas.py
# -----------------------------------------------------
# Normalizador de recetas – v1.4.9
# Mejora de fracciones, rangos, unidades y encabezados
# -----------------------------------------------------

from __future__ import annotations
import re
from core.logger import log_info

# ------------------------------------------------------------------
# Utilidades básicas
# ------------------------------------------------------------------
def limpiar_nombre(texto: str) -> str:
    """Elimina símbolos no alfanuméricos (excepto espacios)."""
    return "".join(c for c in texto if c.isalnum() or c.isspace()).strip()


def extraer_url_origen(texto: str) -> str:
    """Devuelve la primera URL http/https encontrada; vacío si no hay."""
    m = re.search(r"https?://\S+", texto)
    return m.group(0).strip() if m else ""


def extraer_nombre(texto: str) -> str:
    """Toma la primera línea “real” como nombre y limpia frases genéricas."""
    frases_excluir = [
        "cómo hacerlo", "como hacerlo", "paso a paso", "en casa",
        "receta fácil", "receta casera", "al estilo", "delicioso",
        "súper fácil", "rápido", "al horno", "sin horno", "fácil de hacer",
    ]
    for linea in texto.splitlines():
        limpio = limpiar_nombre(linea.lower())
        if limpio and not limpio.startswith("http"):
            for fr in frases_excluir:
                if fr in limpio:
                    limpio = limpio.split(fr)[0].strip(",.:; ")
            return limpio.capitalize() if limpio else "Receta sin nombre"
    return "Receta sin nombre"


def extraer_porciones(texto: str) -> int:
    patrones = [
        r"(?:raciones|porciones|servings)[:\s]+(\d+)",
        r"para\s+(\d+)\s+(?:raciones|porciones|pan(?:es)?|unidades)",
    ]
    for pat in patrones:
        m = re.search(pat, texto, re.IGNORECASE)
        if m:
            return int(m.group(1))
    return 0


def extraer_calorias(texto: str) -> int:
    m = re.search(r"(?:calor[ií]as|calories)[:\s]+(\d+)", texto, re.IGNORECASE)
    return int(m.group(1)) if m else 0


# ------------------------------------------------------------------
# Tabla de fracciones Unicode → float
# ------------------------------------------------------------------
_FRACCIONES = {
    "½": 0.5, "¼": 0.25, "¾": 0.75,
    "⅓": 1 / 3, "⅔": 2 / 3,
    "⅛": 0.125, "⅜": 0.375, "⅝": 0.625, "⅞": 0.875,
}


def _unicode_frac_a_float(texto: str) -> str:
    for char, val in _FRACCIONES.items():
        texto = texto.replace(char, f"{val}")
    return texto


# ------------------------------------------------------------------
# Unidades extra y normalización
# ------------------------------------------------------------------
_UNIDADES_EXTRA = {
    "cda": "cda", "cdas": "cda", "cucharada": "cda", "cucharadas": "cda",
    "tbsp": "tbsp",
    "cdta": "cdta", "cucharadita": "cdta", "cucharaditas": "cdta",
    "tsp": "tsp",
    "taza": "taza", "tazas": "taza",
    "cup": "cup", "cups": "cup",
    "g": "g", "kg": "kg", "ml": "ml", "l": "l",
}


# ------------------------------------------------------------------
# Parser de línea de ingrediente
# ------------------------------------------------------------------
def parsear_linea_ingrediente(linea: str) -> dict | None:
    """Devuelve dict {nombre, cantidad, unidad} o None si no matchea."""
    linea = linea.lstrip("-•▪ ").strip()

    # 1) fracciones Unicode sueltas
    linea = _unicode_frac_a_float(linea)

    # 2) fracciones con barra U+2044 (1⁄4)
    linea = re.sub(
        r"(\d+)\u2044(\d+)",
        lambda m: str(float(m.group(1)) / float(m.group(2))),
        linea,
    )

    # 3) rangos 2-3 → 2
    linea = re.sub(
        r"(?P<min>\d+(?:[\.,]\d+)?)\s*-\s*\d+(?:[\.,]\d+)?",
        r"\g<min>",
        linea,
    )

    # 4) números mixtos 1 0.5 → 1.5
    linea = re.sub(
        r"\b(\d+)\s+(\d+\.\d+)\b",
        lambda m: str(float(m.group(1)) + float(m.group(2))),
        linea,
    )

    patron = (
        r"(?P<cantidad>\d+(?:[\.,]\d+)?)\s*"
        r"(?P<unidad>[A-Za-zµºª]+)?\s+"
        r"(?P<nombre>.+)"
    )
    m = re.match(patron, linea)
    if not m:
        return None

    cantidad = float(m.group("cantidad").replace(",", "."))
    unidad_raw = (m.group("unidad") or "").lower()
    unidad = _UNIDADES_EXTRA.get(unidad_raw, unidad_raw or "unidad")

    nombre = m.group("nombre").strip()
    if nombre.lower().startswith(("de ", "of ")):
        nombre = nombre.split(" ", 1)[1]

    return {"nombre": nombre, "cantidad": cantidad, "unidad": unidad}


# ------------------------------------------------------------------
# Parser de bloque de ingredientes
# ------------------------------------------------------------------
def parsear_ingredientes(texto: str) -> list[dict]:
    secciones = ["ingredientes", "ingredients"]
    ingredientes: list[dict] = []

    for encabezado in secciones:
        m = re.search(
            rf"{encabezado}(?:\s+for|\s+para)?(?:\s+\d+\s+\w+)?[:\n]",
            texto,
            re.IGNORECASE,
        )
        if not m:
            continue

        bloque = texto[m.end():]
        for linea in bloque.splitlines():
            if not linea.strip():
                continue
            if re.search(
                r"preparaci[oó]n|instrucciones|preparation|instructions",
                linea,
                re.IGNORECASE,
            ):
                break
            ing = parsear_linea_ingrediente(linea)
            if ing:
                ingredientes.append(ing)
        if ingredientes:
            break
    return ingredientes


# ------------------------------------------------------------------
# Extracción de pasos de preparación
# ------------------------------------------------------------------
def extraer_preparacion(texto: str) -> str:
    m = re.search(
        r"preparaci[oó]n|instrucciones|preparation|instructions",
        texto,
        re.IGNORECASE,
    )
    return texto[m.end():].strip() if m else ""


# ------------------------------------------------------------------
# Función principal del módulo
# ------------------------------------------------------------------
def normalizar_receta_desde_texto(texto: str) -> dict:
    receta = {
        "nombre": extraer_nombre(texto),
        "url_origen": extraer_url_origen(texto),
        "porciones": extraer_porciones(texto),
        "calorias_totales": extraer_calorias(texto),
        "ingredientes": parsear_ingredientes(texto),
        "preparacion": extraer_preparacion(texto),
    }
    log_info(f"🍴 Receta normalizada: {receta['nombre']}")
    return receta
