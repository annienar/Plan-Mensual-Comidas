from core.logger import configurar_logger, log_info, log_warning, log_error
import logging
logging.getLogger("pdfminer").setLevel(logging.ERROR)  # o WARNING si los quieres ver una sola vez

from core.logger import configurar_logger, log_info, log_warning, log_error
logger = configurar_logger("extraer_pdf")

import pdfplumber

import pdfplumber
logger = configurar_logger("extraer_pdf")

def extraer_texto_desde_pdf(path_pdf):
    texto_extraido = ""
    try:
        with pdfplumber.open(path_pdf) as pdf:
            for pagina in pdf.pages:
                contenido = pagina.extract_text()
                if contenido:
                    texto_extraido += contenido + "\n"
        log_info(f"📄 Texto extraído correctamente de {path_pdf}")
    except Exception as e:
        log_error(f"❌ Error al leer {path_pdf}: {e}")
    return texto_extraido.strip()
 