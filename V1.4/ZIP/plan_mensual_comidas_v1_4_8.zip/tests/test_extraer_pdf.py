# tests/test_extraer_pdf.py
from pathlib import Path
import argparse

from core.logger import configurar_logger, log_info, log_warning, log_error
from core.extraer_pdf import extraer_texto_desde_pdf

logger = configurar_logger("test_extraer_pdf")

CARPETA_SIN_PROCESAR = Path("recetas/sin_procesar")
EXTS_PDF = {".pdf"}

def procesar_pdf(path: Path) -> None:
    log_info(f"📄 Leyendo {path.name}…")
    try:
        texto = extraer_texto_desde_pdf(str(path))
        if texto:
            log_info("📝 Contenido extraído:\n" + "-"*40 + f"\n{texto}\n" + "-"*40)
        else:
            log_warning("⚠️  El PDF no contiene texto embebido.")
    except Exception as e:
        log_error(f"❌ Error al extraer {path.name}: {e}")

def main() -> None:
    parser = argparse.ArgumentParser(description="Test de extracción de PDFs")
    parser.add_argument("--path", help="Ruta a un PDF concreto")
    args = parser.parse_args()

    if args.path:
        p = Path(args.path)
        if p.exists() and p.suffix.lower() in EXTS_PDF:
            procesar_pdf(p)
        else:
            log_warning(f"⚠️  Archivo no válido: {args.path}")
        return

    if not CARPETA_SIN_PROCESAR.exists():
        log_warning(f"📂 Carpeta no encontrada: {CARPETA_SIN_PROCESAR}")
        return

    pdfs = [p for p in CARPETA_SIN_PROCESAR.iterdir() if p.suffix.lower() in EXTS_PDF]
    if not pdfs:
        log_warning("⚠️  No se encontraron archivos .pdf para probar.")
        return

    for p in pdfs:
        procesar_pdf(p)

if __name__ == "__main__":
    main()
