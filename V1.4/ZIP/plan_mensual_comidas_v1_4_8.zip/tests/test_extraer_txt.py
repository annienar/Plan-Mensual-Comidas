"""test_extraer_txt.py – prueba local del extractor TXT

✅ Objetivo
   • Verificar que `core.extraer_txt.extraer_texto_desde_txt` lee correctamente un
     archivo `.txt` colocado en `recetas/sin_procesar/`.
   • No sube nada a Notion ni crea carpetas nuevas (solo lee e imprime).
   • Usa el logger central, sin crear handlers duplicados.

Cómo usar
---------
$ python -m tests.test_extraer_txt
(o ejecutarlo directamente con `python tests/test_extraer_txt.py`)
"""

import os
import sys
from pathlib import Path

# Aseguramos que el proyecto raíz esté en sys.path para import relativos
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))

from core.logger import configurar_logger, log_info, log_warning, log_error
from core.extraer_txt import extraer_texto_desde_txt

logger = configurar_logger("test_extraer_txt")  # crea archivo .log independiente

# ------------------------------------------------------------------
# Configuración de la prueba
# ------------------------------------------------------------------

CARPETA_SIN_PROCESAR = ROOT / "recetas" / "sin_procesar"
EXTENSIONES_TXT      = (".txt",)


def main() -> None:
    if not CARPETA_SIN_PROCESAR.exists():
        log_warning(f"📂 Carpeta no encontrada: {CARPETA_SIN_PROCESAR}")
        return

    archivos_txt = [p for p in CARPETA_SIN_PROCESAR.iterdir() if p.suffix.lower() in EXTENSIONES_TXT]
    if not archivos_txt:
        log_warning("⚠️  No se encontraron archivos .txt para probar.")
        return

    # Procesamos el primero (o todos si se desea)
    for path in archivos_txt:
        log_info(f"📄 Leyendo {path.name}…")
        try:
            texto = extraer_texto_desde_txt(str(path))
            log_info("📝 Contenido extraído:\n" + "-" * 40 + f"\n{texto}\n" + "-" * 40)
        except Exception as e:
            log_error(f"❌ Error al extraer {path.name}: {e}")


if __name__ == "__main__":
    main()
