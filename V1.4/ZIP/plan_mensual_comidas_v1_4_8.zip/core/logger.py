"""
Logger central del proyecto Plan Mensual de Comidas
---------------------------------------------------
• Un archivo por módulo  → .log/<versión>/log-<mm-dd-HHMM>-<módulo>.txt
• Mensajes visibles en consola *sin* duplicarse.
• La cabecera de versión se escribe solo en el archivo (nivel DEBUG),
  de modo que nunca “ensucia” la salida en pantalla.
"""

from __future__ import annotations

import logging
import os
from datetime import datetime
from pathlib import Path

# ------------------------------------------------------------------ #
# 1. Datos de versión (se lee VERSION.txt; si no existe → "0.0.0")
# ------------------------------------------------------------------ #
VERSION_FILE = Path(__file__).resolve().parents[1] / "VERSION.txt"
VERSION_STR  = VERSION_FILE.read_text(encoding="utf-8").strip() if VERSION_FILE.exists() else "0.0.0"

# Carpeta raíz de logs (.log/Vx.x.x/)
LOG_ROOT = Path(".log") / VERSION_STR
LOG_ROOT.mkdir(parents=True, exist_ok=True)

_FMT = "%(asctime)s - %(levelname)s - %(message)s"


def configurar_logger(nombre_modulo: str) -> logging.Logger:
    """
    Configura (una sola vez) el logger raíz y devuelve la misma
    instancia para cualquier módulo que la solicite.
    """
    root = logging.getLogger()

    # Si *ya* hay handlers significa que otro módulo lo configuró antes.
    if root.handlers:
        return root

    root.setLevel(logging.DEBUG)              # TODO se guarda en archivo.

    # ---------- FileHandler -------------------------------------------------
    ts = datetime.now().strftime("log-%m-%d-%H%M")
    log_path = LOG_ROOT / f"{ts}-{nombre_modulo}.txt"
    fh = logging.FileHandler(log_path, encoding="utf-8")
    fh.setFormatter(logging.Formatter(_FMT))
    fh.setLevel(logging.DEBUG)                # DEBUG → ERROR al archivo
    root.addHandler(fh)

    # ---------- StreamHandler (consola) -------------------------------------
    ch = logging.StreamHandler()
    ch.setFormatter(logging.Formatter(_FMT))
    ch.setLevel(logging.INFO)                 # INFO → ERROR a pantalla
    root.addHandler(ch)

    # ---------- Cabecera (SOLO en el archivo) -------------------------------
    root.debug(f"=== Versión {VERSION_STR} | módulo: {nombre_modulo} ===")

    # Evitamos que librerías de terceros inunden la consola con WARNINGs
    # (por ejemplo pdfminer).  Se baja su verbosity a ERROR.
    for noisy in ("pdfminer", "pdfplumber", "PIL"):
        logging.getLogger(noisy).setLevel(logging.ERROR)

    return root


# ------------------------------------------------------------------ #
# 2. Wrappers de uso “one-liner”                                     #
#    Llaman directamente al logger raíz, **una sola vez**.           #
# ------------------------------------------------------------------ #
def log_info(msg: str)    -> None: logging.getLogger().info(msg)
def log_warning(msg: str) -> None: logging.getLogger().warning(msg)
def log_error(msg: str)   -> None: logging.getLogger().error(msg)
