import re
import json
from core.logger import log_info

# ------------------------------------------------------------------
# Utilidades básicas
# ------------------------------------------------------------------

def limpiar_nombre(texto: str) -> str:
    """Elimina símbolos no alfanuméricos (excepto espacios)."""
    return ''.join(c for c in texto if c.isalnum() or c.isspace()).strip()


def extraer_url_origen(texto: str) -> str:
    """Devuelve la primera URL http/https encontrada; vacío si no hay."""
    match = re.search(r"https?://\S+", texto)
    return match.group(0).strip() if match else ""

# ------------------------------------------------------------------
# Extracción de metadatos
# ------------------------------------------------------------------

def extraer_nombre(texto: str) -> str:
    """Toma la primera línea "real" como nombre y limpia frases genéricas."""
    frases_excluir = [
        "cómo hacerlo", "como hacerlo", "paso a paso", "en casa", "receta fácil",
        "receta casera", "al estilo", "delicioso", "súper fácil", "rápido",
        "al horno", "sin horno", "fácil de hacer"
    ]
    for linea in texto.splitlines():
        limpio = limpiar_nombre(linea.lower())
        if limpio and not limpio.startswith("http"):
            for fr in frases_excluir:
                if fr in limpio:
                    limpio = limpio.split(fr)[0].strip(",.:; ")
            return limpio.capitalize() if limpio else "Receta sin nombre"
    return "Receta sin nombre"


def extraer_porciones(texto: str) -> int:
    """Busca expresiones tipo "Raciones: 9", "9 porciones", etc."""
    patrones = [
        r"(?:raciones|porciones|servings)[:\s]+(\d+)",
        r"para\s+(\d+)\s+(?:raciones|porciones|pan(es)?|unidades)",
    ]
    for pat in patrones:
        m = re.search(pat, texto, re.IGNORECASE)
        if m:
            return int(m.group(1))
    return 0


def extraer_calorias(texto: str) -> int:
    m = re.search(r"(?:calor[ií]as|calories)[:\s]+(\d+)", texto, re.IGNORECASE)
    return int(m.group(1)) if m else 0

# ------------------------------------------------------------------
# Ingredientes y preparación
# ------------------------------------------------------------------

def parsear_ingredientes(texto: str):
    secciones = ["ingredientes", "ingredients"]
    ingredientes = []
    for encabezado in secciones:
        m = re.search(rf"{encabezado}[:\n]", texto, re.IGNORECASE)
        if not m:
            continue
        bloque = texto[m.end():]
        for linea in bloque.splitlines():
            if not linea.strip():
                continue
            # Fin de la sección si encontramos estas palabras clave
            if re.search(r"preparaci[oó]n|instrucciones|preparation|instructions", linea, re.IGNORECASE):
                break
            ing = parsear_linea_ingrediente(linea)
            if ing:
                ingredientes.append(ing)
        if ingredientes:
            break
    return ingredientes


def parsear_linea_ingrediente(linea: str):
    # Limpia viñetas ("-", "•", "▪")
    linea = linea.lstrip("-•▪ ")
    patrón = r"(?P<cantidad>\d+(?:[\.,]\d+)?)\s*(?P<unidad>[a-zA-Zµºª]+)?\s*(?P<nombre>.+)"
    m = re.match(patrón, linea.strip())
    if not m:
        return None
    nombre = m.group("nombre").strip()
    # Eliminar prefijos "de" / "of"
    if nombre.lower().startswith("de "):
        nombre = nombre[3:]
    elif nombre.lower().startswith("of "):
        nombre = nombre[3:]
    return {
        "nombre": nombre,
        "cantidad": float(m.group("cantidad").replace(",", ".")),
        "unidad": m.group("unidad") or "unidad"
    }


def extraer_preparacion(texto: str) -> str:
    m = re.search(r"preparaci[oó]n|instrucciones|preparation|instructions", texto, re.IGNORECASE)
    if not m:
        return ""
    return texto[m.end():].strip()

# ------------------------------------------------------------------
# Tags simples
# ------------------------------------------------------------------

def inferir_tags(ingredientes, preparacion):
    tags = []
    if any("huevo" in i["nombre"].lower() or "egg" in i["nombre"].lower() for i in ingredientes):
        tags.append("proteico")
    if len(ingredientes) <= 4:
        tags.append("simple")
    return tags

# ------------------------------------------------------------------
# Función principal
# ------------------------------------------------------------------

def normalizar_receta_desde_texto(texto: str):
    log_info("Iniciando normalización de receta")

    origen      = extraer_url_origen(texto)
    nombre      = extraer_nombre(texto.replace(origen, "")) if origen else extraer_nombre(texto)
    porciones   = extraer_porciones(texto)
    calorias    = extraer_calorias(texto)
    ingredientes = parsear_ingredientes(texto)
    preparacion = extraer_preparacion(texto)
    tags        = inferir_tags(ingredientes, preparacion)

    receta = {
        "nombre": nombre,
        "origen": origen or "Desconocido",
        "porciones": porciones,
        "calorias": calorias,
        "ingredientes": ingredientes,
        "preparacion": preparacion,
        "tags": tags
    }

    log_info("Receta normalizada correctamente")
    return receta
